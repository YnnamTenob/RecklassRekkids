﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Collections.Generic;

namespace RecklassRekkids.Test
{
    [TestClass]
    public class TestSearchEngine
    {
        /// <summary>
        /// Scenario: Search for active music contracts
        //  Given the supplied reference data
        //  When user perform search by ITunes 03-01-2012
	    //  Then the output should be
	    //    | Artist       | Title                   | Usages           | StartDate    | EndDate |
	    //    | Monkey Claw  | Black Mountain          | digital download | 02-01-2012   |         |
	    //    | Monkey Claw  | Motor Mouth             | digital download | 03-01-2011   |         |
	    //    | Tinie Tempah | Frisky(Live from SoHo) | digital download | 02-01-2012   |         |
	    //    | Tinie Tempah | Miami 2 Ibiza           | digital download | 02-01-2012   |         |

        /// </summary>
        [TestMethod]
        public void TestContractScenario()
        {
            var contracts = ContractLoaderFactory.Load("Data\\MusicContracts.txt", new MusicContract());
            var partners = ContractLoaderFactory.Load("Data\\DistPartnerContracts.txt", new PartnerContract());

            var partner = SearchEngine.SearchPartner("ITunes", partners).FirstOrDefault();
            Assert.IsNotNull(partner);
            var rights = SearchEngine.Search(partner, contracts, DateTime.Parse("03-01-2012")).ToList();
            Assert.IsNotNull(rights);
            Assert.IsTrue(rights.Count == 4);
            //
            var expected = new List<Tuple<string, string, string, DateTime?, DateTime?>>
            {
                Tuple.Create("Monkey Claw", "Black Mountain", "digital download", new DateTime?(DateTime.Parse("02-01-2012")) , new DateTime?() ),
                Tuple.Create("Monkey Claw", "Motor Mouth", "digital download", new DateTime?(DateTime.Parse("03-01-2011")) , new DateTime?() ),
                Tuple.Create("Tinie Tempah", "Frisky (Live from SoHo)", "digital download", new DateTime?(DateTime.Parse("02-01-2012")) , new DateTime?() ),
                Tuple.Create("Tinie Tempah", "Miami 2 Ibiza", "digital download", new DateTime?(DateTime.Parse("02-01-2012")) , new DateTime?() )
            };

            Assert.IsTrue(
                 rights.All(r => 
                    expected.Any(e => r.Item1 == e.Item1  
                                 && r.Item2 == e.Item2 
                                 && r.Item3 == e.Item3 
                                 && r.Item4 == e.Item4 
                                 && r.Item5 == e.Item5
                                 )));

        }

        /// <summary>
        //Scenario: Search for active music contracts_2
        //   Given the supplied reference data

        //   When user perform search by YouTube 12-27-2012

        //   Then the output should be
	    //| Artist       | Title                   | Usages    | StartDate     | EndDate       |
	    //| Monkey Claw  | Christmas Special       | streaming | 12-25-2012    | 12-31-2012    |
	    //| Monkey Claw  | Iron Horse              | streaming | 06-01-2012    |               |
	    //| Monkey Claw  | Motor Mouth             | streaming | 03-01-2011    |               |
	    //| Tinie Tempah | Frisky(Live from SoHo) | streaming | 02-01-2012    |               |

        /// </summary>
        [TestMethod]
        public void TestContractScenario2()
        {
            var contracts = ContractLoaderFactory.Load("Data\\MusicContracts.txt", new MusicContract());
            var partners = ContractLoaderFactory.Load("Data\\DistPartnerContracts.txt", new PartnerContract());

            var partner = SearchEngine.SearchPartner("YouTube", partners).FirstOrDefault();
            Assert.IsNotNull(partner);
            var rights = SearchEngine.Search(partner, contracts, DateTime.Parse("12-27-2012")).ToList();
            Assert.IsNotNull(rights);
            Assert.IsTrue(rights.Count == 4);
            //
            var expected = new List<Tuple<string, string, string, DateTime?, DateTime?>>
            {
                Tuple.Create("Monkey Claw", "Christmas Special", "streaming", new DateTime?(DateTime.Parse("12-25-2012")) , new DateTime?(DateTime.Parse("12-31-2012")) ),
                Tuple.Create("Monkey Claw", "Iron Horse", "streaming", new DateTime?(DateTime.Parse("06-01-2012")) , new DateTime?() ),
                Tuple.Create("Monkey Claw", "Motor Mouth", "streaming", new DateTime?(DateTime.Parse("03-01-2011")) , new DateTime?() ),
                Tuple.Create("Tinie Tempah", "Frisky (Live from SoHo)", "streaming", new DateTime?(DateTime.Parse("02-01-2012")) , new DateTime?() )
            };

            Assert.IsTrue(
                 rights.All(r =>
                    expected.Any(e => r.Item1 == e.Item1
                                 && r.Item2 == e.Item2
                                 && r.Item3 == e.Item3
                                 && r.Item4 == e.Item4
                                 && r.Item5 == e.Item5
                                 )));

        }

        /// <summary>
        /// Scenario: Search for active music contracts_3
        //       Given the supplied reference data
        //       When user perform search by YouTube 04-01-2012
        //Then the output should be
	        //| Artist       | Title                   | Usages    | StartDate    | EndDate |
	        //| Monkey Claw  | Motor Mouth             | streaming | 03-01-2011   |         |
	        //| Tinie Tempah | Frisky(Live from SoHo) | streaming | 02-01-2012   |         |

        /// </summary>
        [TestMethod]
        public void TestContractScenario3()
        {
            var contracts = ContractLoaderFactory.Load("Data\\MusicContracts.txt", new MusicContract());
            var partners = ContractLoaderFactory.Load("Data\\DistPartnerContracts.txt", new PartnerContract());

            var partner = SearchEngine.SearchPartner("YouTube", partners).FirstOrDefault();
            Assert.IsNotNull(partner);
            var rights = SearchEngine.Search(partner, contracts, DateTime.Parse("04-01-2012")).ToList();
            Assert.IsNotNull(rights);
            Assert.IsTrue(rights.Count == 2);
            //
            var expected = new List<Tuple<string, string, string, DateTime?, DateTime?>>
            {
                Tuple.Create("Monkey Claw", "Motor Mouth", "streaming", new DateTime?(DateTime.Parse("03-01-2011")) , new DateTime?() ),
                Tuple.Create("Tinie Tempah", "Frisky (Live from SoHo)", "streaming", new DateTime?(DateTime.Parse("02-01-2012")) , new DateTime?() )
            };

            Assert.IsTrue(
                 rights.All(r =>
                    expected.Any(e => r.Item1 == e.Item1
                                 && r.Item2 == e.Item2
                                 && r.Item3 == e.Item3
                                 && r.Item4 == e.Item4
                                 && r.Item5 == e.Item5
                                 )));

        }
    }
}
