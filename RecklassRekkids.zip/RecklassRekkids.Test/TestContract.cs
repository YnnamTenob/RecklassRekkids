﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;

namespace RecklassRekkids.Test
{
    [TestClass]
    public class TestMusicContract
    {
        [TestMethod]
        public void TestCreateMusicContractSingleUsageNullEndDate()
        {
            var line = "Tinie Tempah|Miami 2 Ibiza|digital download|02-01-2012|";
            var contract = new MusicContract(line);

            Assert.IsNotNull(contract);
            Assert.IsTrue(contract.Artist == "Tinie Tempah");
            Assert.IsTrue(contract.Title == "Miami 2 Ibiza");
            Assert.IsNotNull(contract.Usages);
            var usage = contract.Usages.SingleOrDefault();
            Assert.IsNotNull(usage);
            Assert.IsTrue(usage == "digital download");
            Assert.IsNotNull(contract.StartDate);
            Assert.IsTrue(contract.StartDate == DateTime.Parse("02-01-2012"));
            Assert.IsNull(contract.EndDate);

        }

        [TestMethod]
        public void TestCreateMusicContractSingleUsageEndDate()
        {
            var line = "Monkey Claw|Christmas Special|streaming|12-25-2012|12-31-2012";
            var contract = new MusicContract(line);

            Assert.IsNotNull(contract);
            Assert.IsTrue(contract.Artist == "Monkey Claw");
            Assert.IsTrue(contract.Title == "Christmas Special");
            Assert.IsNotNull(contract.Usages);
            var usage = contract.Usages.SingleOrDefault();
            Assert.IsNotNull(usage);
            Assert.IsTrue(usage == "streaming");
            Assert.IsNotNull(contract.StartDate);
            Assert.IsTrue(contract.StartDate == DateTime.Parse("12-25-2012"));
            Assert.IsNotNull(contract.EndDate);
            Assert.IsTrue(contract.EndDate == DateTime.Parse("12-31-2012"));

        }

        [TestMethod]
        public void TestCreateMusicContractSingleMultiUsageNoEndDate()
        {
            var line = "Tinie Tempah|Frisky (Live from SoHo)|digital download, streaming|02-01-2012|";
            var contract = new MusicContract(line);

            Assert.IsNotNull(contract);
            Assert.IsTrue(contract.Artist == "Tinie Tempah");
            Assert.IsTrue(contract.Title == "Frisky (Live from SoHo)");
            Assert.IsNotNull(contract.Usages);
            
            
            Assert.IsTrue(contract.Usages.All(c => c == "digital download" | c == "streaming") && contract.Usages.Count == 2);
            Assert.IsNotNull(contract.StartDate);
            Assert.IsTrue(contract.StartDate == DateTime.Parse("02-01-2012"));
            Assert.IsNull(contract.EndDate);

        }


    }

    [TestClass]
    public class TestPartnerContract
    {
        [TestMethod]
        public void TestCreatePartnerContract()
        {
            var line = "ITunes|digital download";
            var contract = new PartnerContract(line);

            Assert.IsNotNull(contract);
            Assert.IsTrue(contract.Partner == "ITunes");
            Assert.IsTrue(contract.Usage == "digital download");
        }
    }
}
