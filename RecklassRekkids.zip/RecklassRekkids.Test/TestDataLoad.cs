﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RecklassRekkids.Test
{
    [TestClass]
    public class TestDataLoad
    {
        [TestMethod]
        public void TestLoadMusicContracts()
        {
            var contracts = ContractLoaderFactory.Load("Data\\MusicContracts.txt", new MusicContract());
            Assert.IsNotNull(contracts);
            Assert.IsTrue(contracts.Count == 7);
        }

        [TestMethod]
        public void TestLoadPartnerContracts()
        {
            var contracts = ContractLoaderFactory.Load("Data\\DistPartnerContracts.txt", new PartnerContract());
            Assert.IsNotNull(contracts);
            Assert.IsTrue(contracts.Count == 2);
        }


    }
}
