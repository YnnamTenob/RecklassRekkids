﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecklassRekkids
{
    public class SearchEngine
    {
        public static IEnumerable<Tuple<string, string, string, DateTime?, DateTime?>> Search(PartnerContract partner, List<MusicContract> contracts, DateTime effectiveDate)
        {
            var searchResults =
                from c in contracts
                where c.Usages.Any(u => u == partner.Usage) && c.StartDate <= effectiveDate
                select Tuple.Create(c.Artist, c.Title, partner.Usage, c.StartDate, c.EndDate);

            return searchResults;
        }

        public static IEnumerable<PartnerContract> SearchPartner(string name, List<PartnerContract> contracts)
        {
            var searchResults =
                from c in contracts
                where c.Partner == name
                select c;
            return searchResults;
        }
    }
}
