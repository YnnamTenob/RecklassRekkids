﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecklassRekkids
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter a delivery partner name and an effective date");

            var searchCriteria = Console.ReadLine().Split(' ');

            if (searchCriteria.Length != 2)
            {
                Console.WriteLine("Invalid Command Sequence");
                return;
            }

            var contracts = ContractLoaderFactory.Load("Data\\MusicContracts.txt", new MusicContract());
            var partners = ContractLoaderFactory.Load("Data\\DistPartnerContracts.txt", new PartnerContract());

            var partner = SearchEngine.SearchPartner(searchCriteria[0], partners).FirstOrDefault();
            var rights = SearchEngine.Search(partner, contracts, DateTime.Parse(searchCriteria[1])).ToList();

            Console.WriteLine("Artist       | Title                   | Usages           | StartDate    | EndDate ");
            rights.ForEach(r => Console.WriteLine("{0,-13}| {1,-25}| {2,-16}| {3,-11}| {4,-11}", r.Item1, r.Item2, r.Item3, r.Item4, r.Item5));

            Console.WriteLine();
            Console.WriteLine("Hit Any Key to Exit");
            Console.ReadLine();
        }
    }
}
