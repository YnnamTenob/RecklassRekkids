﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecklassRekkids
{
    public interface IContract
    {
        Func<string,IContract> Resolve { get; }
    }

    public class MusicContract : IContract
    {

        public MusicContract()
        {
            Usages = new List<string>();
        }

        public MusicContract(string line)
        {
            var props = line.Split('|');
            Artist = props[0];
            Title = props[1];

            Usages = props[2].Split(',').Select(u=>u.Trim()).ToList();
            DateTime startDate = DateTime.MaxValue;
            DateTime endDate = DateTime.MinValue;
            StartDate = (DateTime.TryParse(props[3], out startDate)) ? startDate : new DateTime?() ;
            EndDate = props.Length == 5 && (DateTime.TryParse(props[4], out endDate)) ? endDate : new DateTime?();
        }

        public string Artist { get; set; }
        public string Title { get; set; }

        public List<string> Usages { get; private set; }

        public DateTime? StartDate { get; private set; }

        public DateTime? EndDate { get; private set; }

        public Func<string, IContract> Resolve
        {
            get { return  l => new MusicContract(l); }
        }

        public override string ToString()
        {
            // Format
            // | Artist | Title | Usage | Start Date | End Date |

            return base.ToString();
        }
    }

    public class PartnerContract : IContract
    {

        public PartnerContract()
        {

        }

        public PartnerContract(string line)
        {
            var props = line.Split('|');
            Partner = props[0];
            Usage = props[1];
        }

        public string Partner { get; set; }
        public string Usage { get; set; }


        public Func<string, IContract> Resolve
        {
            get { return l => new PartnerContract(l); }
        }
    }
}
