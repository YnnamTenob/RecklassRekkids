﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace RecklassRekkids
{
    public class ContractLoaderFactory 
    {

        public static List<TContract> Load<TContract>(string fileName, TContract contract) where TContract : IContract
        {
            if (string.IsNullOrEmpty(fileName)) { throw new NullReferenceException("File Name must not be null"); }
            
            if ( contract == null) { throw new NullReferenceException("Contract must not be null"); }
            var list = new List<TContract>();
            if (File.Exists(fileName))
                using (var reader = File.OpenText(fileName))
                {
                    var lineCount = 0;
                    while (!reader.EndOfStream)
                    {

                        var line = reader.ReadLine();
                        lineCount++;
                        //skip header line
                        if(lineCount > 1)
                            list.Add((TContract)contract.Resolve(line) );
                    }
                }

            return list;
        }

    }
}
